def cubesurface(l,b,h):
    return (2*(l*b + b*h + l*h))
def cubelateral(l,b,h):
    return (2*h*(l + b) )
