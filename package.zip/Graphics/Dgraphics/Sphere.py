from math import pi
def SphereArea(r):
    return (4*pi*r*r)

def SpherePerimeter(r):
    return ((4/3)*pi*r*r*r)
