from math import pi
def CircleArea(r):
    return (pi*r*r)
def CirclePerimeter(r):
    return (2*pi*r)
