def RectangleArea(l, b):
    return (l*b)

def RectanglePerimeter(l, b):
    return (2*(l+b))
